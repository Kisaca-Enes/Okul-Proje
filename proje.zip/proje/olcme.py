#!/usr/bin/env python3
"""
Fruit & Vegetable pH Classifier + PyQt5 UI
- Adds a dataset of 40 fruits/vegetables (placeholder image filenames)
- Uses simple color/hue based heuristics adapted from user's script
- PyQt5 interface: load image, shows a black transient overlay "pH {value}" for 3s,
  then fades out and shows full classification results.

Requirements:
  pip install PyQt5 pillow numpy matplotlib

Save as fruit_ph_gui.py and run:
  python fruit_ph_gui.py

Note: reference image filenames are placeholders — replace them with your real
images if you want histogram-based matching. The code falls back to hue/profile
matching if references are missing.
"""

import sys
import os
import math
import numpy as np
from PIL import Image, ImageQt
from matplotlib.colors import rgb_to_hsv
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QFileDialog, QTextEdit, QFrame, QGraphicsOpacityEffect
)
from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation
from PyQt5.QtGui import QPixmap, QFont

# ------------------------ Dataset & Properties -----------------------------
# 40 fruits/vegetables with example placeholder filenames (replace with your images)
DATASET = {
    # fruits
    'elma': ['elma1.jpg', 'elma2.jpg'],
    'armut': ['armut1.jpg', 'armut2.jpg'],
    'muz': ['muz1.jpg', 'muz2.jpg'],
    'limon': ['limon1.jpg', 'limon2.jpg'],
    'portakal': ['portakal1.jpg', 'portakal2.jpg'],
    'mandalina': ['mandalina1.jpg'],
    'greyfurt': ['greyfurt1.jpg'],
    'avokado': ['avokado1.jpg'],
    'karpuz': ['karpuz1.jpg'],
    'kavun': ['kavun1.jpg'],
    'mango': ['mango1.jpg'],
    'papaya': ['papaya1.jpg'],
    'kivi': ['kivi1.jpg'],
    'cilek': ['cilek1.jpg'],
    'kiraz': ['kiraz1.jpg'],
    'uzum': ['uzum1.jpg'],
    'blueberry': ['blue1.jpg'],
    'ahududu': ['ahududu1.jpg'],
    # vegetables
    'domates': ['domates1.jpg'],
    'salatalik': ['salatalik1.jpg'],
    'biber': ['biber1.jpg'],
    'patates': ['patates1.jpg'],
    'tatli_patates': ['tatli_patates1.jpg'],
    'havuç': ['havuç1.jpg'],
    'pancar': ['pancar1.jpg'],
    'soğan': ['sogan1.jpg'],
    'sarmisak': ['sarmisak1.jpg'],
    'brokoli': ['brokoli1.jpg'],
    'karnabahar': ['karnabahar1.jpg'],
    'ispanak': ['ispanak1.jpg'],
    'marul': ['marul1.jpg'],
    'lahana': ['lahana1.jpg'],
    'enginar': ['enginar1.jpg'],
    'patlican': ['patlican1.jpg'],
    'salatabostan': ['salatabostan1.jpg'],
    'bezelye': ['bezelye1.jpg'],
    'mantar': ['mantar1.jpg'],
    'kabak': ['kabak1.jpg'],
}

# pH and acidity/basicity properties for each label (example values)
PROPERTIES = {
    'elma': {'ph': 6.2, 'asit': 'düşk', 'baz': 'düşk'},
    'armut': {'ph': 7.5, 'asit': 'düşk', 'baz': 'orta'},
    'muz': {'ph': 5.5, 'asit': 'orta', 'baz': 'düşk'},
    'limon': {'ph': 2.2, 'asit': 'çok yüksek', 'baz': 'düşk'},
    'portakal': {'ph': 3.5, 'asit': 'yüksek', 'baz': 'düşk'},
    'mandalina': {'ph': 3.4, 'asit': 'yüksek', 'baz': 'düşk'},
    'greyfurt': {'ph': 3.0, 'asit': 'yüksek', 'baz': 'düşk'},
    'avokado': {'ph': 6.3, 'asit': 'düşk', 'baz': 'düşk'},
    'karpuz': {'ph': 5.2, 'asit': 'düşk', 'baz': 'düşk'},
    'kavun': {'ph': 6.3, 'asit': 'düşk', 'baz': 'düşk'},
    'mango': {'ph': 5.8, 'asit': 'orta', 'baz': 'düşk'},
    'papaya': {'ph': 5.5, 'asit': 'orta', 'baz': 'düşk'},
    'kivi': {'ph': 3.1, 'asit': 'yüksek', 'baz': 'düşk'},
    'cilek': {'ph': 3.0, 'asit': 'yüksek', 'baz': 'düşk'},
    'kiraz': {'ph': 3.9, 'asit': 'yüksek', 'baz': 'düşk'},
    'uzum': {'ph': 3.3, 'asit': 'yüksek', 'baz': 'düşk'},
    'blueberry': {'ph': 3.1, 'asit': 'yüksek', 'baz': 'düşk'},
    'ahududu': {'ph': 3.2, 'asit': 'yüksek', 'baz': 'düşk'},
    'domates': {'ph': 4.2, 'asit': 'orta', 'baz': 'düşk'},
    'salatalik': {'ph': 5.1, 'asit': 'düşk', 'baz': 'düşk'},
    'biber': {'ph': 5.3, 'asit': 'orta', 'baz': 'düşk'},
    'patates': {'ph': 5.6, 'asit': 'düşk', 'baz': 'orta'},
    'tatli_patates': {'ph': 5.3, 'asit': 'düşk', 'baz': 'düşk'},
    'havuç': {'ph': 6.0, 'asit': 'düşk', 'baz': 'düşk'},
    'pancar': {'ph': 5.5, 'asit': 'orta', 'baz': 'düşk'},
    'soğan': {'ph': 5.5, 'asit': 'orta', 'baz': 'düşk'},
    'sarmisak': {'ph': 6.0, 'asit': 'düşk', 'baz': 'düşk'},
    'brokoli': {'ph': 6.3, 'asit': 'düşk', 'baz': 'düşk'},
    'karnabahar': {'ph': 5.8, 'asit': 'düşk', 'baz': 'düşk'},
    'ispanak': {'ph': 6.8, 'asit': 'düşk', 'baz': 'orta'},
    'marul': {'ph': 6.2, 'asit': 'düşk', 'baz': 'düşk'},
    'lahana': {'ph': 6.0, 'asit': 'düşk', 'baz': 'orta'},
    'enginar': {'ph': 6.5, 'asit': 'düşk', 'baz': 'düşk'},
    'patlican': {'ph': 5.6, 'asit': 'orta', 'baz': 'düşk'},
    'bezelye': {'ph': 6.0, 'asit': 'düşk', 'baz': 'düşk'},
    'mantar': {'ph': 6.0, 'asit': 'düşk', 'baz': 'düşk'},
    'kabak': {'ph': 6.5, 'asit': 'düşk', 'baz': 'düşk'},
}

# Average hue profiles for quick matching (ranges in [0,1]) -- rough approximations
HUE_PROFILES = {
    'elma': [(0.0, 0.08), (0.95, 1.0)],  # red or green
    'armut': [(0.12, 0.24)],  # yellow-green
    'muz': [(0.12, 0.18)],
    'limon': [(0.12, 0.16)],
    'portakal': [(0.05, 0.12)],
    'mandalina': [(0.05, 0.12)],
    'greyfurt': [(0.05, 0.12)],
    'avokado': [(0.12, 0.26)],
    'karpuz': [(0.95, 1.0), (0.0, 0.08)],
    'kavun': [(0.12, 0.22)],
    'mango': [(0.05, 0.16)],
    'papaya': [(0.05, 0.16)],
    'kivi': [(0.2, 0.35)],
    'cilek': [(0.0, 0.03)],
    'kiraz': [(0.98, 1.0), (0.0, 0.03)],
    'uzum': [(0.65, 0.85)],
    'blueberry': [(0.6, 0.75)],
    'ahududu': [(0.97, 1.0), (0.0, 0.03)],
    'domates': [(0.98, 0.03)],
    'salatalik': [(0.25, 0.45)],
    'biber': [(0.98, 0.08)],
    'patates': [(0.08, 0.16)],
    'tatli_patates': [(0.05, 0.12)],
    'havu\u00e7': [(0.03, 0.08)],
    'pancar': [(0.95, 1.0)],
    'so\u011fan': [(0.0, 1.0)],
    'sarmisak': [(0.0, 1.0)],
    'brokoli': [(0.25, 0.38)],
    'karnabahar': [(0.0, 1.0)],
    'ispanak': [(0.25, 0.4)],
    'marul': [(0.25, 0.4)],
    'lahana': [(0.5, 0.7)],
    'enginar': [(0.08, 0.18)],
    'patlican': [(0.6, 0.75)],
    'bezelye': [(0.25, 0.4)],
    'mantar': [(0.0, 1.0)],
    'kabak': [(0.12, 0.2)],
}

# ------------------------ Image processing helpers ------------------------

def load_image_array(path, size_limit=None):
    """Return HxWx3 numpy array scaled to [0,1]."""
    img = Image.open(path).convert('RGB')
    if size_limit is not None:
        img.thumbnail(size_limit)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr


def temizle_beyaz_arr(arr, s_thresh=0.15, v_thresh=0.9):
    """Mask near-white pixels out (return same shape arr but white pixels zeroed).
    arr: HxWx3 float [0,1]
    """
    hsv = rgb_to_hsv(arr)
    mask = ~((hsv[:, :, 1] < s_thresh) & (hsv[:, :, 2] > v_thresh))
    res = arr.copy()
    res[~mask] = 0.0
    return res


def ortalama_hue_arr(arr):
    arr2 = temizle_beyaz_arr(arr)
    hsv = rgb_to_hsv(arr2)
    # ignore zeroed pixels
    valid = (arr2.mean(axis=2) > 0)
    if valid.sum() == 0:
        return 0.0
    return float(hsv[:, :, 0][valid].mean())


def tahmini_olgunluk(arr):
    """Simple ripeness heuristic from original: returns one of green/orta/olgun/cok_olgun
    """
    a = temizle_beyaz_arr(arr)
    hsv = rgb_to_hsv(a)
    valid = (a.mean(axis=2) > 0)
    if valid.sum() == 0:
        return 'bilinmiyor'
    H = float(hsv[:, :, 0][valid].mean())
    S = float(hsv[:, :, 1][valid].mean())
    V = float(hsv[:, :, 2][valid].mean())
    if V > 0.7 and S > 0.5:
        return 'yesil'
    elif V > 0.5 and S > 0.4:
        return 'orta'
    elif V > 0.3 and S > 0.2:
        return 'olgun'
    else:
        return 'cok_olgun'


def aspect_ratio_pil(path, threshold=120):
    img = Image.open(path).convert('L')
    img = img.point(lambda p: 255 if p > threshold else 0)
    arr = np.asarray(img, dtype=np.uint8)
    ys, xs = np.where(arr == 0)
    if len(xs) == 0 or len(ys) == 0:
        return 1.0
    width = int(xs.max() - xs.min() + 1)
    height = int(ys.max() - ys.min() + 1)
    if height == 0:
        return 1.0
    return width / height


def renk_score_arr(arr, target_label):
    H = ortalama_hue_arr(arr)
    a = temizle_beyaz_arr(arr)
    hsv = rgb_to_hsv(a)
    valid = (a.mean(axis=2) > 0)
    if valid.sum() == 0:
        S = V = 0.0
    else:
        S = float(hsv[:, :, 1][valid].mean())
        V = float(hsv[:, :, 2][valid].mean())
    score = 0.0
    if target_label in HUE_PROFILES:
        for (low, high) in HUE_PROFILES[target_label]:
            # handle wrap-around ranges like (0.95,1.0)+(0,0.05)
            if low <= high:
                if low <= H <= high and S > 0.25 and V > 0.15:
                    score = 1.0
                    break
            else:
                if (H >= low or H <= high) and S > 0.25 and V > 0.15:
                    score = 1.0
                    break
    return score


def histogram_similarity_fallback(arr, ref_path):
    try:
        ref = load_image_array(ref_path, size_limit=(300, 300))
    except Exception:
        return 0.0
    a1 = temizle_beyaz_arr(arr)
    a2 = temizle_beyaz_arr(ref)
    mask1 = a1.mean(axis=2) > 0.02
    mask2 = a2.mean(axis=2) > 0.02
    vals1 = a1[mask1].flatten()
    vals2 = a2[mask2].flatten()
    if vals1.size == 0 or vals2.size == 0:
        return 0.0
    h1, _ = np.histogram(vals1, bins=256, range=(0, 1), density=True)
    h2, _ = np.histogram(vals2, bins=256, range=(0, 1), density=True)
    denom = (np.linalg.norm(h1) * np.linalg.norm(h2))
    if denom == 0:
        return 0.0
    return float(np.dot(h1, h2) / denom)

# ------------------------ Classification logic ---------------------------

def classify_image(arr, image_path=None):
    """Return best label, properties, and ripeness.
    Strategy:
      - For each label: try histogram similarity with any existing reference image file.
      - Also compute hue/profile score and aspect similarity.
      - Combine into total_score and pick best.
    """
    best = None
    best_score = -1.0
    new_aspect = None
    if image_path is not None:
        try:
            new_aspect = aspect_ratio_pil(image_path)
        except Exception:
            new_aspect = 1.0

    for label, refs in DATASET.items():
        # histogram similarity: try to find any existing reference image file
        hist_best = 0.0
        for r in refs:
            if os.path.exists(r):
                hist_val = histogram_similarity_fallback(arr, r)
                if hist_val > hist_best:
                    hist_best = hist_val
        # aspect similarity: compare to first existing ref if available
        aspect_diff = 0.5
        ref_aspect = None
        for r in refs:
            if os.path.exists(r):
                try:
                    ref_aspect = aspect_ratio_pil(r)
                    break
                except Exception:
                    ref_aspect = None
        if new_aspect is not None and ref_aspect is not None:
            aspect_diff = 1.0 - abs(new_aspect - ref_aspect)
            aspect_diff = max(0.0, min(1.0, aspect_diff))
        # hue/profile score
        r_score = renk_score_arr(arr, label)
        total = 0.5 * hist_best + 0.3 * aspect_diff + 0.2 * r_score
        # fallback: if user's references missing, rely on hue/profile alone
        if all(not os.path.exists(x) for x in refs):
            total = r_score
        if total > best_score:
            best_score = total
            best = label
    if best is None:
        best = 'bilinmiyor'
    ripeness = tahmini_olgunluk(arr)
    props = PROPERTIES.get(best, {'ph': 6.0, 'asit': 'bilinmiyor', 'baz': 'bilinmiyor'})
    # adjust pH by ripeness
    adjusted_ph = props['ph']
    if ripeness == 'cok_olgun':
        adjusted_ph += 0.5
    elif ripeness == 'olgun':
        adjusted_ph += 0.2
    return best, props, ripeness, adjusted_ph, best_score

# ------------------------ PyQt5 UI ---------------------------------------

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Meyve/Sebze pH Tahmini')
        self.setMinimumSize(900, 600)
        self.setup_ui()

    def setup_ui(self):
        main_layout = QHBoxLayout()

        # Left: image preview and controls
        left = QVBoxLayout()
        self.preview_label = QLabel('Resim yok')
        self.preview_label.setFrameStyle(QFrame.Box | QFrame.Plain)
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setMinimumSize(400, 400)
        left.addWidget(self.preview_label)

        btn_layout = QHBoxLayout()
        load_btn = QPushButton('Resim Yükle')
        load_btn.clicked.connect(self.load_image)
        btn_layout.addWidget(load_btn)
        left.addLayout(btn_layout)

        # Right: results
        right = QVBoxLayout()
        self.results = QTextEdit()
        self.results.setReadOnly(True)
        self.results.setFont(QFont('Consolas', 11))
        right.addWidget(self.results)

        main_layout.addLayout(left, 2)
        main_layout.addLayout(right, 1)
        self.setLayout(main_layout)

        # transient overlay for pH display (black background, big text)
        self.overlay = QLabel(self)
        self.overlay.setStyleSheet('background-color: black; color: white;')
        self.overlay.setAlignment(Qt.AlignCenter)
        font = QFont('Arial', 36, QFont.Bold)
        self.overlay.setFont(font)
        self.overlay.setVisible(False)
        self.overlay.setAttribute(Qt.WA_StyledBackground)
        self.opacity_effect = QGraphicsOpacityEffect(self.overlay)
        self.overlay.setGraphicsEffect(self.opacity_effect)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # keep overlay full window
        self.overlay.setGeometry(0, 0, self.width(), self.height())

    def load_image(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Resim seç', '', 'Images (*.png *.jpg *.jpeg *.bmp)')
        if not path:
            return
        try:
            arr = load_image_array(path, size_limit=(800, 800))
        except Exception as e:
            self.results.setPlainText(f'Resim yüklenemedi: {e}')
            return
        # show preview
        qimg = ImageQt.ImageQt(Image.open(path).convert('RGB'))
        pix = QPixmap.fromImage(qimg)
        pix = pix.scaled(self.preview_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.preview_label.setPixmap(pix)

        # classify
        label, props, ripeness, adjusted_ph, score = classify_image(arr, image_path=path)

        # show transient pH overlay
        self.show_ph_overlay(adjusted_ph)

        # prepare full results text (displayed after overlay fades)
        text = []
        text.append(f'Nesne tespit edildi: {label}')
        text.append(f'Benzerlik skoru (0-1): {score:.3f}')
        text.append(f'Olgunluk durumu: {ripeness}')
        text.append(f'Orijinal pH değeri: {props.get("ph", "?")}')
        text.append(f'Olgunluk sonrası pH değeri: {adjusted_ph:.2f}')
        text.append(f'Asit gücü: {props.get("asit", "?")}')
        text.append(f'Baz gücü: {props.get("baz", "?")}')
        text.append('\nNot: Referans resim dosyalarını DATASET sözlüğüne ekleyin\n(aynı dizinde ya da tam yol verin)\n')
        self.full_results_text = '\n'.join(text)

    def show_ph_overlay(self, ph_value):
        self.overlay.setText(f'pH {ph_value:.2f}')
        self.opacity_effect.setOpacity(1.0)
        self.overlay.setVisible(True)
        # Show for 3s, then animate fade out over 1.5s and then display results
        QTimer.singleShot(3000, self.fade_out_overlay)

    def fade_out_overlay(self):
        anim = QPropertyAnimation(self.opacity_effect, b"opacity")
        anim.setDuration(1500)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.finished.connect(self.on_overlay_hidden)
        anim.start()
        # keep a reference so it doesn't get GC'd
        self._anim = anim

    def on_overlay_hidden(self):
        self.overlay.setVisible(False)
        # show full results
        self.results.setPlainText(self.full_results_text)


# ------------------------ Main -------------------------------------------

def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()

